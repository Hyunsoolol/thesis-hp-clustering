# CSDA manuscript, 260915-00

Main: manuscript_260915-00.tex

Supplement: supplement_260915-00.tex

Select the desired file as the Overleaf Main document. Use pdfLaTeX and BibTeX. Both documents compile independently; all input paths are relative to this folder. The included PDFs were built with TeX Live 2026.

This revision expands the explanation of the vMF mixture in Section 2.1 and clarifies statistical terminology throughout the methods, results and supplement. The Introduction, approved Abstract, AI declaration, numbered equations, Algorithm 1, proof appendix, numerical results and figure files are unchanged. Section 2.1 adds unnumbered explanatory formulas; no models were refitted.

The package includes editable TeX, external tables, figures, bibliography, class/style files and PDFs. Raw corpora and model-fitting archives are not included.
