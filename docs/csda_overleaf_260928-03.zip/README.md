# CSDA manuscript package, 2026-09-28, revision 03

## Compilation

Use pdfLaTeX and BibTeX. In Overleaf, set the main document to
`manuscript_260928-03.tex`. To compile the separate Supplement, select
`supplement_260928-02.tex` instead. Keep the table and figure directories intact.
The included Elsevier class and bibliography style are those used for the
verified local build (TeX Live 2026).

Both compiled PDFs are included. `SHA256SUMS.txt` records the hashes of all
delivered files other than the checksum list itself. This is a manuscript
source package, not the full simulation code or raw-data archive.

## Companion data

The three CSV files are in `tables_260928-02/`.

- `supplementary_simulation_summary.csv`: 155 method-condition groups, each
  with 100 replications. Unsuffixed metric columns are means; `_sd` columns
  are sample standard deviations. An MCSE of a mean is `_sd / sqrt(valid_reps)`.
  `MSE_mu` and `MSE_kappa` for E-CGL and E-ACGL use the saved corrected fits.
  In the pure-concentration condition, the true directional-contrast support
  is empty. Its TPR, precision, F1 and corresponding standard deviations are
  reported as `NA`; the defined FPR and exact-recovery metrics are retained.
- `csda_final_section44_ecgl_sample_size_260804.csv`: the sample-size results.
  The unused historical `elapsed_sec_median` column is not included.
- `csda_supp_section44_oracle_selector_260803.csv`: the oracle and selector
  comparisons, unchanged in this revision.

Dates in individual table filenames identify the original table layout, not
the numerical release date. The versioned directory identifies this release.

## Revision scope

This revision corrects the Supplement's S6-S8 table ordering, S22 placement,
and one Bessel-series line break. Companion CSV conventions and the two
E-series auxiliary MSE columns are synchronized with saved corrected outputs.
No model fitting was repeated. The model, theoretical results, algorithms,
main-text results, Abstract and AI declaration are unchanged from the preceding
advisor-revision draft.

Revision 03 adds one intuitive sentence in Main Section 2.1: groups may
differ in mean direction, concentration around that direction, or both.
The Supplement remains revision 02. All tables, figures, companion data,
formulas, results, and the AI declaration are unchanged.
