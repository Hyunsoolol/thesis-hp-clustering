# CSDA manuscript package, 2026-09-28, revision 04

## Compilation

Use pdfLaTeX and BibTeX. In Overleaf, select `manuscript_260928-04.tex`
for the main article or `supplement_260928-02.tex` for the Supplement.
Keep the supplied table and figure directories intact. The included Elsevier
class and bibliography style were used for the verified TeX Live 2026 build.

Both PDFs are included. `SHA256SUMS.txt` lists the SHA-256 hashes of every
delivered file except the checksum list itself. This package contains the
manuscript sources, not the full simulation code or raw-data archive.

## Revision scope

Revision 04 distinguishes the subsequence step-size limit from its upper bound,
clarifies mixing-proportion clipping and MCSEs, corrects two grammatical details,
replaces an improvement-rate comparison with the observed recovery rate,
clarifies the stress-table dashes, and records the separate convergence checks
for the four additional E-CGL sample-size conditions at target error 0.10.

The Supplement remains revision 02. No model fitting was repeated. All table
entries, figures, companion CSVs, the Abstract, and the AI declaration are
unchanged. The only changed table file is the stress table in `tables_260928-04/`;
its numerical entries are unchanged. Other tables retain their validated paths.

## Companion data

The three CSV files remain in `tables_260928-02/`.

- `supplementary_simulation_summary.csv`: 155 method-condition groups, each
  with 100 replications. Unsuffixed metric columns are means; `_sd` columns
  are sample standard deviations. An MCSE of a mean is `_sd / sqrt(valid_reps)`.
  E-series `MSE_mu` and `MSE_kappa` use saved corrected fits. For the empty
  directional-contrast support in the pure-concentration condition, TPR,
  precision, F1, and their standard deviations are `NA`; FPR and exact recovery
  remain defined.
- `csda_final_section44_ecgl_sample_size_260804.csv`: sample-size results.
- `csda_supp_section44_oracle_selector_260803.csv`: oracle and selector results.

Dates in table filenames identify the original layout, not the numerical
release date. Versioned directories distinguish subsequent document revisions.
